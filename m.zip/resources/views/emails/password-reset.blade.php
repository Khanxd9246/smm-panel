<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Reset Your Password</title>
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  body{background:#0f1117;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#e2e8f0}
  .wrapper{max-width:560px;margin:40px auto;padding:0 16px 60px}
  .card{background:#1a1d2e;border:1px solid #2d3148;border-radius:16px;overflow:hidden}
  .header{background:linear-gradient(135deg,#f76f6f 0%,#f7a76f 100%);padding:40px 32px;text-align:center}
  .header .icon{width:64px;height:64px;background:rgba(255,255,255,.15);border-radius:50%;display:inline-flex;align-items:center;justify-content:center;margin-bottom:16px}
  .header h1{font-size:24px;font-weight:800;color:#fff;letter-spacing:-.3px}
  .header p{font-size:14px;color:rgba(255,255,255,.8);margin-top:8px}
  .body{padding:32px}
  .greeting{font-size:15px;color:#a0aec0;margin-bottom:24px;line-height:1.6}
  .greeting strong{color:#e2e8f0}
  .btn-wrap{text-align:center;margin:28px 0}
  .btn{display:inline-block;background:linear-gradient(135deg,#f76f6f,#f7a76f);color:#fff;text-decoration:none;border-radius:12px;padding:15px 40px;font-size:15px;font-weight:700;letter-spacing:.01em;box-shadow:0 8px 24px rgba(247,111,111,.3)}
  .divider{border:none;border-top:1px solid #1e2235;margin:24px 0}
  .fallback{background:#11141f;border:1px solid #1e2235;border-radius:10px;padding:16px;font-size:12px;color:#718096;line-height:1.7;word-break:break-all}
  .fallback a{color:#f76f6f;word-break:break-all}
  .warning-box{background:rgba(247,111,111,.06);border:1px solid rgba(247,111,111,.15);border-radius:10px;padding:14px 16px;font-size:13px;color:#c08080;margin-top:20px;line-height:1.6}
  .footer-text{font-size:12px;color:#4a5568;text-align:center;line-height:1.6;margin-top:28px}
  .app-name{color:#f76f6f;font-weight:700}
</style>
</head>
<body>
<div class="wrapper">
  <div class="card">

    <div class="header">
      <div class="icon">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
          <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
        </svg>
      </div>
      <h1>Password Reset</h1>
      <p>We received a request to reset your password</p>
    </div>

    <div class="body">
      <p class="greeting">
        Hi <strong>{{ $userName ?? 'there' }}</strong>,<br><br>
        Click the button below to reset your password. This link will expire in <strong>60 minutes</strong>.
      </p>

      <div class="btn-wrap">
        <a href="{{ $actionUrl }}" class="btn">Reset My Password</a>
      </div>

      <hr class="divider">

      <div class="fallback">
        <strong style="color:#a0aec0;display:block;margin-bottom:6px">Button not working?</strong>
        Copy and paste this link into your browser:<br>
        <a href="{{ $actionUrl }}">{{ $actionUrl }}</a>
      </div>

      <div class="warning-box">
        🔒 If you did not request a password reset, please ignore this email. Your password will remain unchanged and no action is needed.
      </div>
    </div>

  </div>
  <p class="footer-text">
    Sent by <span class="app-name">{{ config('app.name') }}</span> · Please do not reply to this email.
  </p>
</div>
</body>
</html>
